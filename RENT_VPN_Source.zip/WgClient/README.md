# RENT VPN — Android client

RENT VPN is a Kotlin + Jetpack Compose Android client based on the official WireGuard Android tunnel library.

## Included in this source version
- Dark premium purple/cyan Compose interface
- Home screen with connection state and connect/disconnect action
- WireGuard `.conf` import using Android document picker
- Paste configuration from clipboard
- Download a text WireGuard configuration from an HTTPS URL
- Local private-app storage for the configuration
- Android VPN permission flow and real WireGuard tunnel lifecycle
- Basic settings screen

## Important protocol scope
This build implements **WireGuard only**. It does not yet implement VLESS, VMess, Trojan, Shadowsocks, subscription decoding, QR scanning, server latency measurement, per-app routing, or traffic accounting. Those features require additional protocol engines and integration work; the UI must not be mistaken for support that is not present.

## Build
Open `WgClient` in Android Studio (JDK 17, Android Gradle Plugin 8.5.2 or compatible), sync Gradle, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Or run `gradle :app:assembleDebug` in an environment with Gradle installed.

The generated debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

## Use
1. Obtain a valid WireGuard client configuration from a VPN server you administer or are authorized to use.
2. Import its `.conf` file, paste its contents, or provide an HTTPS URL that returns the raw WireGuard config.
3. Tap Connect and approve Android's VPN permission dialog.

Never share the `PrivateKey` in your configuration. The app stores the configuration in its private app directory, but this initial version does not encrypt it at rest.
