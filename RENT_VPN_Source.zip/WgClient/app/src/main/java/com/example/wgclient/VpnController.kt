package com.example.wgclient

import android.content.Context
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Управление WireGuard-туннелем и локальной конфигурацией. */
object VpnController {
    private var backend: GoBackend? = null
    private val _state = MutableStateFlow(Tunnel.State.DOWN)
    val state: StateFlow<Tunnel.State> = _state
    private val tunnel = object : Tunnel {
        override fun getName(): String = "rentvpn"
        override fun onStateChange(newState: Tunnel.State) { _state.value = newState }
    }
    private fun backend(context: Context): GoBackend = backend ?: GoBackend(context.applicationContext).also { backend = it }

    suspend fun connect(context: Context, configText: String) = withContext(Dispatchers.IO) {
        require(configText.contains("[Interface]") && configText.contains("[Peer]")) { "Ожидается WireGuard-конфигурация с [Interface] и [Peer]" }
        val config = Config.parse(configText.byteInputStream())
        backend(context).setState(tunnel, Tunnel.State.UP, config)
    }
    suspend fun disconnect(context: Context) = withContext(Dispatchers.IO) { backend(context).setState(tunnel, Tunnel.State.DOWN, null) }
    private fun file(context: Context) = File(context.filesDir, "rentvpn-tunnel.conf")
    fun loadConfig(context: Context): String = file(context).takeIf { it.exists() }?.readText().orEmpty()
    fun saveConfig(context: Context, text: String) { file(context).writeText(text) }

    /** Загружает текстовый WireGuard-конфиг по HTTPS. */
    suspend fun fetchConfig(address: String): String = withContext(Dispatchers.IO) {
        require(address.startsWith("https://")) { "Разрешены только HTTPS-ссылки" }
        val connection = (URL(address).openConnection() as HttpURLConnection).apply {
            connectTimeout = 12000
            readTimeout = 12000
            requestMethod = "GET"
            instanceFollowRedirects = true
        }
        try {
            require(connection.responseCode in 200..299) { "HTTP ${connection.responseCode}" }
            val text = connection.inputStream.bufferedReader().use { it.readText() }
            require(text.length <= 1024 * 1024) { "Файл слишком большой" }
            require(text.contains("[Interface]") && text.contains("[Peer]")) { "Ссылка не вернула WireGuard-конфигурацию" }
            text
        } finally { connection.disconnect() }
    }
}
