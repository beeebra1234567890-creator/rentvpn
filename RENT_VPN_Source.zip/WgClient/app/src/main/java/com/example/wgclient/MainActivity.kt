package com.example.wgclient

import android.app.Activity
import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import kotlinx.coroutines.launch

private val Bg = Color(0xFF080912)
private val Panel = Color(0xFF131525)
private val Purple = Color(0xFF9875FF)
private val Cyan = Color(0xFF5DE1E6)
private val Muted = Color(0xFF9296AE)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RentVpnApp() }
    }
}

@Composable
private fun RentVpnApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    val state by VpnController.state.collectAsState()
    var config by remember { mutableStateOf(VpnController.loadConfig(context)) }
    var profileName by remember { mutableStateOf("Мой WireGuard") }
    var importUrl by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    val connected = state == Tunnel.State.UP

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            scope.launch {
                busy = true
                runCatching { VpnController.saveConfig(context, config); VpnController.connect(context, config) }
                    .onFailure { message = "Не удалось подключиться: ${it.message ?: "проверьте конфигурацию"}" }
                busy = false
            }
        } else message = "Разрешение Android VPN не выдано"
    }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) runCatching { readText(context, uri) }
            .onSuccess { config = it; VpnController.saveConfig(context, it); message = "Конфигурация импортирована" }
            .onFailure { message = "Не удалось прочитать файл" }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, secondary = Cyan, background = Bg, surface = Panel)) {
        Column(Modifier.fillMaxSize().background(Bg)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(Purple, Cyan))), contentAlignment = Alignment.Center) {
                    Text("R", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("RENT VPN", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.5.sp)
                    Text("PRIVATE CONNECTION", color = Muted, fontSize = 9.sp, letterSpacing = 2.sp)
                }
                Box(Modifier.clip(CircleShape).background(Color(0xFF1C2030)).padding(horizontal = 12.dp, vertical = 8.dp)) {
                    Text(if (connected) "● ONLINE" else "● OFFLINE", color = if (connected) Cyan else Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
            when (tab) {
                0 -> HomeScreen(connected, config, profileName, message, busy,
                    onConnect = {
                        if (connected) scope.launch { runCatching { VpnController.disconnect(context) }.onFailure { message = it.message ?: "Ошибка отключения" } }
                        else if (config.isBlank()) message = "Сначала импортируйте WireGuard-конфигурацию"
                        else {
                            val intent = GoBackend.VpnService.prepare(context)
                            if (intent != null) permissionLauncher.launch(intent) else scope.launch {
                                busy = true
                                runCatching { VpnController.saveConfig(context, config); VpnController.connect(context, config) }
                                    .onFailure { message = "Ошибка: ${it.message ?: "неверная конфигурация"}" }
                                busy = false
                            }
                        }
                    }, onServers = { tab = 1 })
                1 -> ServersScreen(profileName, config, importUrl, onName = { profileName = it }, onConfig = { config = it }, onUrl = { importUrl = it },
                    onFile = { filePicker.launch(arrayOf("*/*")) },
                    onPaste = { clipboard.getText()?.text?.let { config = it; message = "Текст вставлен" } ?: run { message = "Буфер обмена пуст" } },
                    onFetch = {
                        scope.launch {
                            busy = true
                            runCatching { VpnController.fetchConfig(importUrl) }
                                .onSuccess { config = it; VpnController.saveConfig(context, it); message = "Конфигурация загружена" }
                                .onFailure { message = "Не удалось загрузить: ${it.message ?: "ошибка сети"}" }
                            busy = false
                        }
                    }, busy = busy)
                else -> SettingsScreen(onClear = { config = ""; VpnController.saveConfig(context, ""); message = "Локальная конфигурация удалена" })
            }
            Spacer(Modifier.weight(1f))
            Row(Modifier.fillMaxWidth().background(Color(0xFF101321)).padding(vertical = 12.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                NavItem("⌂", "Главная", tab == 0) { tab = 0 }
                NavItem("◎", "Серверы", tab == 1) { tab = 1 }
                NavItem("⚙", "Настройки", tab == 2) { tab = 2 }
            }
        }
    }
}

@Composable
private fun HomeScreen(connected: Boolean, config: String, profile: String, message: String, busy: Boolean, onConnect: () -> Unit, onServers: () -> Unit) {
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(20.dp))
        Text("ТВОЯ СЕТЬ. ТВОИ ПРАВИЛА.", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(28.dp))
        Box(contentAlignment = Alignment.Center, modifier = Modifier.size(238.dp).clip(CircleShape).background(Brush.radialGradient(listOf(Color(0xFF34265E), Color(0xFF17172C), Bg))).border(1.dp, Purple.copy(alpha = .45f), CircleShape).padding(18.dp)) {
            Box(Modifier.fillMaxSize().border(1.dp, Cyan.copy(alpha = .18f), CircleShape), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (connected) "ЗАЩИЩЕНО" else "НЕ ЗАЩИЩЕНО", color = if (connected) Cyan else Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = onConnect, enabled = !busy, modifier = Modifier.size(126.dp), shape = CircleShape, colors = ButtonDefaults.buttonColors(containerColor = if (connected) Color(0xFF263D48) else Purple)) {
                        Text(if (busy) "..." else if (connected) "Ⅱ" else "⏻", fontSize = 43.sp, color = Color.White)
                    }
                    Spacer(Modifier.height(9.dp))
                    Text(if (connected) "ОТКЛЮЧИТЬ" else "ПОДКЛЮЧИТЬ", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                }
            }
        }
        Spacer(Modifier.height(26.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("PING", if (connected) "— ms" else "—", "Задержка", Modifier.weight(1f))
            MetricCard("ТРАФИК", "— MB", "Передано", Modifier.weight(1f))
        }
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel).clickable { onServers() }.padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("◈", color = Purple, fontSize = 25.sp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) { Text("Текущий профиль", color = Muted, fontSize = 11.sp); Text(if (config.isBlank()) "Сервер не добавлен" else profile, color = Color.White, fontWeight = FontWeight.SemiBold) }
            Text("Изменить  ›", color = Cyan, fontSize = 11.sp)
        }
        if (message.isNotBlank()) { Spacer(Modifier.height(12.dp)); Text(message, color = if (message.contains("Ошибка") || message.contains("Не удалось")) Color(0xFFFF8292) else Cyan, fontSize = 12.sp) }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun MetricCard(title: String, value: String, caption: String, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(18.dp)).background(Panel).padding(16.dp)) {
        Text(title, color = Muted, fontSize = 9.sp, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(8.dp)); Text(value, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(caption, color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun ServersScreen(profile: String, config: String, url: String, onName: (String) -> Unit, onConfig: (String) -> Unit, onUrl: (String) -> Unit, onFile: () -> Unit, onPaste: () -> Unit, onFetch: () -> Unit, busy: Boolean) {
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("СЕРВЕРЫ И ПОДПИСКИ", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("Добавьте свой WireGuard-профиль", color = Muted, fontSize = 12.sp)
        OutlinedTextField(value = profile, onValueChange = onName, label = { Text("Название профиля") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(value = url, onValueChange = onUrl, label = { Text("URL конфигурации") }, placeholder = { Text("https://…") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Button(onClick = onFetch, enabled = url.startsWith("https://") && !busy, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "Загрузка…" else "Загрузить по ссылке") }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onFile, modifier = Modifier.weight(1f)) { Text("Импорт файла") }
            OutlinedButton(onClick = onPaste, modifier = Modifier.weight(1f)) { Text("Вставить") }
        }
        Text("WIREGUARD CONFIG", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
        OutlinedTextField(value = config, onValueChange = onConfig, modifier = Modifier.fillMaxWidth().height(230.dp), placeholder = { Text("[Interface]\nPrivateKey = …\nAddress = …\n\n[Peer]\nPublicKey = …\nEndpoint = …") }, textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, fontSize = 11.sp))
        Text("Конфигурации хранятся локально на устройстве. Не передавайте свой PrivateKey другим людям.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun SettingsScreen(onClear: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("НАСТРОЙКИ", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        SettingRow("Приложение", "RENT VPN · версия 1.0")
        SettingRow("Протокол", "WireGuard")
        SettingRow("Хранение", "Локально на устройстве")
        OutlinedButton(onClick = onClear, modifier = Modifier.fillMaxWidth()) { Text("Удалить сохранённую конфигурацию", color = Color(0xFFFF8292)) }
        Text("RENT VPN — VPN-клиент. Для подключения необходим действующий сервер и корректная конфигурация.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun SettingRow(title: String, value: String) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Panel).padding(16.dp)) { Text(title, color = Color.White, fontWeight = FontWeight.SemiBold); Text(value, color = Muted, fontSize = 11.sp) }
}

@Composable
private fun NavItem(icon: String, label: String, selected: Boolean, onClick: () -> Unit) {
    Column(Modifier.clickable { onClick() }.padding(horizontal = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(icon, color = if (selected) Purple else Muted, fontSize = 22.sp)
        Text(label, color = if (selected) Color.White else Muted, fontSize = 10.sp)
    }
}

private fun readText(context: Context, uri: Uri): String = context.contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
